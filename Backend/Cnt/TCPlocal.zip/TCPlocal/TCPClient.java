package TCPlocal;
package TCPLocal;
package TCPLocal;
import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) {
        final String SERVER_IP = "127.0.0.1"; // Replace with the server's IP address
        final int PORT = 8000; // Server port
        String messageToSend = "Hello from client";

        try (Socket socket = new Socket(SERVER_IP, PORT)) {
            // Send data to the server
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);
            writer.println(messageToSend);
            System.out.println("Message sent to server: " + messageToSend);

            // Receive a reply from the server
            InputStream input = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String serverResponse = reader.readLine();
            System.out.println("Message from server: " + serverResponse);
        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}