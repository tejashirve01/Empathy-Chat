package TCPlocal;
package TCPLocal;
package TCPLocal;
import java.io.*;
import java.net.*;

public class TCPServer {
    public static void main(String[] args) {
        final int PORT = 8000; // Port on which the server listens
        String hello = "Hello from server";

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);

            // Accept an incoming client connection
            try (Socket socket = serverSocket.accept()) {
                System.out.println("New client connected");

                // Receive data from the client
                InputStream input = socket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                String clientMessage = reader.readLine();
                System.out.println("Message from client: " + clientMessage);

                // Send a response to the client
                OutputStream output = socket.getOutputStream();
                PrintWriter writer = new PrintWriter(output, true);
                writer.println(hello);
                System.out.println("Hello message sent");
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}